package com.cg.walletapp.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.walletapp.bean.Customer;
import com.cg.walletapp.exception.WalletException;

public interface IWalletService {
	public void addAccount(Customer customer);

	public boolean checkMobno(String mobnum);

	public Customer showBalance(String mobnum);

	public BigDecimal transferFund(String mobnum, String mobnumber, BigDecimal transferamount);

	public BigDecimal depositBalance(String mobnum, BigDecimal amount1);

	public BigDecimal withdrawal(String mobnum, BigDecimal amount2);

	public boolean validateRechargeAmount(String mobnum, BigDecimal amount2)throws WalletException;

	public boolean validateDetails(String name, String mnumber) throws WalletException;

	public List<String> printTransactionDetails();
}
