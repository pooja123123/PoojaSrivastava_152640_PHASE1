package com.cg.walletapp.ui;

import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;

import com.cg.walletapp.bean.Customer;
import com.cg.walletapp.exception.WalletException;
import com.cg.walletapp.service.IWalletService;
import com.cg.walletapp.service.WalletService;


public class WalletMain {
	static IWalletService walletService = new WalletService();

	public static void printMainMenu() {
		System.out.println();
		System.out.println("  " + "=============================WELCOME=============================");
		System.out.println("  " + "*                                                               *");
		System.out.println("  " + "*              ==========PAYTM WALLET APP==========             *");
		System.out.println("  " + "*                        1: SIGNUP FOR NEW ACCOUNT              *");
		System.out.println("  " + "*                        2: LOGIN                               *");
		System.out.println("  " + "*                        3: EXIT                                *");
		System.out.println("  " + "=================================================================");
		
		//System.out.println("Enter your Choice::");
	}

	public static void printAppDetails() {
		System.out.println();
		System.out.println("  " + "*============================WELCOME============================*");
		System.out.println("  " + "*                                                               *");
		System.out.println("  " + "*------------------------PAYTM WALLET APP-----------------------*");
		System.out.println("  " + "*                        1: Show Balance                        *");
		System.out.println("  " + "*                        2: Deposit Amount                      *");
		System.out.println("  " + "*                        3: Withdraw Amount                     *");
		System.out.println("  " + "*                        4: Fund Transfer                       *");
		System.out.println("  " + "*                        5: Print Transaction                   *");
		System.out.println("  " + "*                        6: LOGOUT                              *");
		System.out.println("  " + "*===============================================================*");
		
	//	System.out.println("Enter your Choice ::");
	}

	public static void printOptions(String mobnum) {
		int choice1 = 0;
		Scanner scanner1 = new Scanner(System.in);
		do {
			printAppDetails();
			System.out.println("Enter your choice::");
			choice1 = scanner1.nextInt();
			switch (choice1) {
			case 1:
				Customer customer1 = walletService.showBalance(mobnum);
				System.out.println(
						"Hello : " + customer1.getName() +"\n Your Current Balance is :" + customer1.getWalletBalance());
				break;
			case 2:
				System.out.println("Enter the amount you want to deposit::");
				BigDecimal amount1 = scanner1.nextBigDecimal();
				BigDecimal newbalance = walletService.depositBalance(mobnum, amount1);
				System.out.println("Hello! " +walletService.showBalance(mobnum).getName() 
						+" Your New balance is :" + newbalance);
				break;
			case 3:

				System.out.println("Enter the amount you want to withdraw:");
				BigDecimal amount2 = scanner1.nextBigDecimal();
				try {
					if (walletService.validateRechargeAmount(mobnum, amount2)) {
						BigDecimal newbalance2 = walletService.withdrawal(mobnum, amount2);
						System.out.println("Hello! " +walletService.showBalance(mobnum).getName() 
								+" Your New balance is :" + newbalance2);
					}
				} catch (WalletException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				try {
					System.out.println("Enter the reciever mobile number::");
					String mobnumber = scanner1.next();
					if (walletService.checkMobno(mobnumber)) {
						System.out.println("Enter the amount you want to transfer::");
						BigDecimal transferamount = scanner1.nextBigDecimal();
						if (walletService.validateRechargeAmount(mobnum, transferamount)) {
							BigDecimal balance = walletService.transferFund(mobnum, mobnumber, transferamount);
							System.out.println("Hello :" +walletService.showBalance(mobnum).getName() 
									+" Your New balance is :" + balance);
						}
					}
				} catch (WalletException e) {
					System.out.println(e.getMessage());
				}
				
				break;
			case 5:
				List<String> newList=walletService.printTransactionDetails();
				for(String i: newList) {
					System.out.println(i);
				}
				break;
			case 6:
				main(null);
				break;

			}
		} while (choice1 != 6);
		scanner1.close();
	}

	public static void main(String[] args) {
		int choice = 0;

		Scanner scanner = new Scanner(System.in);
		do {
			printMainMenu();
			System.out.println("Enter your choice:");
			choice = scanner.nextInt();
			Customer customer = new Customer();

			switch (choice) {
			case 1:
				try {
					System.out.println("Enter Your Name:");
					String name = scanner.next();
					System.out.println("Enter Your Mobile Number:");
					String mnumber = scanner.next();
					System.out.println("Enter the amount you want to add to your account:");
					BigDecimal amount = scanner.nextBigDecimal();
					walletService.validateDetails(name, mnumber);
					customer.setName(name);
					customer.setMobileNo(mnumber);
					customer.setWalletBalance(amount);
					walletService.addAccount(customer);

				} catch (WalletException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 2:
				System.out.println("Enter Your mobile number:");
				String mobnumber = scanner.next();
				if (walletService.checkMobno(mobnumber)) {
					printOptions(mobnumber);
				} else {
					System.out.println("Mobile number does not exist!");

				}
				break;
			case 3:
				System.exit(0);

				break;

			}

		} while (choice != 3);

		scanner.close();
	}

}
