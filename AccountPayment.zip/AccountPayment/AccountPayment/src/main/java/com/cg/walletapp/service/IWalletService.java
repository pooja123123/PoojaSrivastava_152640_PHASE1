package com.cg.walletapp.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.walletapp.bean.Customer;
import com.cg.walletapp.exception.WalletException;

public interface IWalletService {
	public abstract void addAccount(Customer customer);

	public abstract boolean checkMobno(String mobNum);

	public abstract Customer showBalance(String mobnum);

	public abstract BigDecimal transferFund(String mobnum, String mobnumber, BigDecimal transferamount);

	public  abstract BigDecimal depositBalance(String mobnum, BigDecimal amount1);

	public abstract BigDecimal withdrawal(String mobnum, BigDecimal amount2);

	public abstract boolean validateRechargeAmount(String mobnum, BigDecimal amount2)throws WalletException;

	public abstract boolean validateDetails(String name, String mnumber) throws WalletException;

	public abstract List<String> printTransactionDetails();
}
