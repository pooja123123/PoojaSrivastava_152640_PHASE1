package com.cg.walletapp.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

import com.cg.walletapp.bean.Customer;
import com.cg.walletapp.dao.WalletDaoImpl;

public class WalletAppTest extends WalletDaoImpl {
	@Test
	public void testAddAccountDao() {
		Customer customer = new Customer();
		customer.setMobileNo("8989898989");
		assertEquals("8989898989", customer.getMobileNo());
	}

	public void testFindOne() {
		Customer customer = new Customer();
		customer.setMobileNo("1234567890");
		assertNotEquals("123", customer.getMobileNo());
	}

}
