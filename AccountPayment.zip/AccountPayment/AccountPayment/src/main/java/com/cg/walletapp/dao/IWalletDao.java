package com.cg.walletapp.dao;

import java.util.List;

import com.cg.walletapp.bean.Customer;

public interface IWalletDao {

	public void addAccountDao(Customer customer);

	public Customer findOne(String mobNum);

	public void addTransactions(String str);

	public List<String> printTransactionsDao();
}
