package com.cg.walletapp.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import com.cg.walletapp.bean.Customer;

public class WalletDaoImpl implements IWalletDao {
	public static Map<String, Customer> walletDetails = null;
	public static List<String> transactionDetails = null;
	
	static {
		walletDetails = new HashMap<String, Customer>();
		transactionDetails = new ArrayList<String>();
		Customer customerOne = new Customer();
		customerOne.setWalletBalance(new BigDecimal("1000"));
		customerOne.setName("Pooja");
		customerOne.setMobileNo("0909090909");
		walletDetails.put(customerOne.getMobileNo(), customerOne);
		Customer customerTwo = new Customer();
		customerTwo.setWalletBalance(new BigDecimal("2000"));
		customerTwo.setName("PoojaSri");
		customerTwo.setMobileNo("1234567890");
		walletDetails.put(customerTwo.getMobileNo(), customerTwo);
	}

	public void addAccountDao(Customer customer) {

		walletDetails.put(customer.getMobileNo(), customer);

	}

	public Map<String, Customer> viewDetail() {

		return walletDetails;
	}

	public Customer findOne(String mobNum) {

		Customer customerFound = new Customer();
		Set<Entry<String, Customer>> set = walletDetails.entrySet();
		Iterator<Entry<String, Customer>> it = set.iterator();
		while (it.hasNext()) {

			Map.Entry<String, Customer> entry = it.next();
			if (entry.getKey().equals(mobNum)) {
				customerFound = entry.getValue();

			}

		}
		return customerFound;
	}

	public void addTransactions(String str) {
		transactionDetails.add(str);

	}

	public List<String> printTransactionsDao() {

		return transactionDetails;
	}

}
